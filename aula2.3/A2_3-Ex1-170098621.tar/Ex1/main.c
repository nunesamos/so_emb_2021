#include <stdio.h>
#include <stdlib.h>
#include "ola.h"

int main(void)
{
    ola_mundo();
    return 0;
}