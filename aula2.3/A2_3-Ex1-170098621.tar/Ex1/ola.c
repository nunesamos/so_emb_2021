#include <stdio.h>
#include "ola.h"

void ola_mundo(void)
{
    printf("Olá Mundo!\n");
}