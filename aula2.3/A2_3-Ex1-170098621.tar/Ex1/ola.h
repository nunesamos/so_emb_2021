#include <stdio.h>

void ola_mundo();