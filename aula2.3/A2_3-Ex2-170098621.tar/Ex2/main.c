#include <stdio.h>
#include <stdlib.h>
#include "mostra.h"

int main(int argc, char **argv)
{
    mostra_dado(argc, argv);
    // printf("teste1\n");
    return 0;
}