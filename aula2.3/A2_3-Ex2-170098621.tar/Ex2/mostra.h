#include <stdio.h>

void mostra_dado(int N, char **argv);