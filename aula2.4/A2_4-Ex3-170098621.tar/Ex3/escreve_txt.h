#include <stdio.h>

void escreve_nome(char *nome, int idade);

