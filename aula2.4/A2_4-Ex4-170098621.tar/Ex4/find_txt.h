#include <stdio.h>

void escreve_nome(char *nome, int idade);
void busca_acha(char *palavra, char *arquivo);

